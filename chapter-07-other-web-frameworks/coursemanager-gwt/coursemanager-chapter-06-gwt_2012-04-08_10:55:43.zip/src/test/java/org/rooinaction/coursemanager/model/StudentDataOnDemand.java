package org.rooinaction.coursemanager.model;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Student.class)
public class StudentDataOnDemand {
}
