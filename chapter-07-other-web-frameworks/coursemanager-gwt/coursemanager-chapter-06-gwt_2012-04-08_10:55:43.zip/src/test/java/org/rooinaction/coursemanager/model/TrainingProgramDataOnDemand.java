package org.rooinaction.coursemanager.model;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = TrainingProgram.class)
public class TrainingProgramDataOnDemand {
}
