package org.rooinaction.coursemanager.shared;


public enum CourseTypeEnum {

    SEMINAR, CREDIT, CONTINUING_EDUCATION
}
