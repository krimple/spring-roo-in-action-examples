package org.rooinaction.coursemanager.model;

public enum FrequencyType {

    WEEKLY, MONTHLY, BIWEEKLY
}
