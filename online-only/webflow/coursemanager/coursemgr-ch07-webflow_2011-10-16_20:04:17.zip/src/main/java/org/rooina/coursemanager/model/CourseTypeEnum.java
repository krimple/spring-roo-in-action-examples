package org.rooina.coursemanager.model;


public enum CourseTypeEnum {

    SEMINAR, CREDIT, CONTINUING_EDUCATION
}
