package org.rooina.coursemanager.model;


public enum FrequencyType {

    WEEKLY, MONTHLY, BIWEEKLY
}
