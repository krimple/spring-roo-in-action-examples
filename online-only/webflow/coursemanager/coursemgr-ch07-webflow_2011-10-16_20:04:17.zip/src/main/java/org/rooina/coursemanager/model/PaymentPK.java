package org.rooina.coursemanager.model;

import org.springframework.roo.addon.entity.RooIdentifier;

@RooIdentifier(dbManaged = true)
public final class PaymentPK {
}
