package org.rooina.coursemanager.model;

import org.junit.Test;
import static org.junit.Assert.*;

public class StudentTest {

    private Student student = new Student();

    @Test
    public void getId() {
        org.junit.Assert.assertTrue(true);
        student.setId(12L);
        assertEquals(new Long(12L), student.getId());
    }

    @Test
    public void setId() {
        org.junit.Assert.assertTrue(true);
    }

    @Test
    public void getFullName() {
        org.junit.Assert.assertTrue(true);
    }

    @Test
    public void getFirstName() {
        org.junit.Assert.assertTrue(true);
    }

    @Test
    public void setFirstName() {
        org.junit.Assert.assertTrue(true);
    }

    @Test
    public void getMiddleNameOrInitial() {
        org.junit.Assert.assertTrue(true);
    }

    @Test
    public void setMiddleNameOrInitial() {
        org.junit.Assert.assertTrue(true);
    }

    @Test
    public void getLastName() {
        org.junit.Assert.assertTrue(true);
    }

    @Test
    public void setLastName() {
        org.junit.Assert.assertTrue(true);
    }

    @Test
    public void getAddressLine1() {
        org.junit.Assert.assertTrue(true);
    }

    @Test
    public void setAddressLine1() {
        org.junit.Assert.assertTrue(true);
    }

    @Test
    public void getAddressLine2() {
        org.junit.Assert.assertTrue(true);
    }

    @Test
    public void setAddressLine2() {
        org.junit.Assert.assertTrue(true);
    }

    @Test
    public void getCity() {
        org.junit.Assert.assertTrue(true);
    }

    @Test
    public void setCity() {
        org.junit.Assert.assertTrue(true);
    }

    @Test
    public void getStateCode() {
        org.junit.Assert.assertTrue(true);
    }

    @Test
    public void setStateCode() {
        org.junit.Assert.assertTrue(true);
    }

    @Test
    public void getPostalCode() {
        org.junit.Assert.assertTrue(true);
    }

    @Test
    public void setPostalCode() {
        org.junit.Assert.assertTrue(true);
    }

    @Test
    public void getEmailAddress() {
        org.junit.Assert.assertTrue(true);
    }

    @Test
    public void setEmailAddress() {
        org.junit.Assert.assertTrue(true);
    }

    @Test
    public void findStudentsNotInOffering() {
        org.junit.Assert.assertTrue(true);
    }

    @Test
    public void findStudentsNotRegisteredForOffering() {
        org.junit.Assert.assertTrue(true);
    }

    @Test
    public void findStudentsRegisteredForOffering() {
        org.junit.Assert.assertTrue(true);
    }

    @Test
    public void findStudentsByName() {
        org.junit.Assert.assertTrue(true);
    }

    @Test
    public void findStudentsByIdIn() {
        org.junit.Assert.assertTrue(true);
    }

    @Test
    public void getEmergencyContactName() {
        org.junit.Assert.assertTrue(true);
    }

    @Test
    public void setEmergencyContactName() {
        org.junit.Assert.assertTrue(true);
    }

    @Test
    public void getEmergencyContactInfo() {
        org.junit.Assert.assertTrue(true);
    }

    @Test
    public void setEmergencyContactInfo() {
        org.junit.Assert.assertTrue(true);
    }

    @Test
    public void getDietaryRestrictions() {
        org.junit.Assert.assertTrue(true);
    }

    @Test
    public void setDietaryRestrictions() {
        org.junit.Assert.assertTrue(true);
    }

    @Test
    public void getRegistrations() {
        org.junit.Assert.assertTrue(true);
    }

    @Test
    public void setRegistrations() {
        org.junit.Assert.assertTrue(true);
    }
}
